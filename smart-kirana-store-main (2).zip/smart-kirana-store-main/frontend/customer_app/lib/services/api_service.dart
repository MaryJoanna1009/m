import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static String baseUrl = "http://192.168.4.28:8000"; 

  static Future<String> sendOtp(String phoneNumber) async {
    final url = Uri.parse("$baseUrl/auth/send_otp?phone_number=$phoneNumber");

    final response = await http.post(url);

    if (response.statusCode == 200) {
      return jsonDecode(response.body)['otp'];  
    } else {
      throw Exception('Failed to send OTP');
    }
  }

  static Future<String> verifyOtp(String phoneNumber, String otp) async {
    final url = Uri.parse("$baseUrl/auth/verify_otp?phone_number=$phoneNumber&otp=$otp");

    final response = await http.post(url);

    if (response.statusCode == 200) {
      return jsonDecode(response.body)['message'];
    } else {
      throw Exception('OTP verification failed');
    }
  }
}

