import 'package:flutter/material.dart';
import 'inventory_screen.dart';
import 'orders_screen.dart';
import 'udhaar_screen.dart';
import 'suppliers_screen.dart';
import 'community_screen.dart';

class KiranaDashboardScreen extends StatelessWidget {
  const KiranaDashboardScreen({super.key});

  Widget buildDashboardItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    required Color color,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.grey,
              blurRadius: 4,
              spreadRadius: 1,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: Colors.white),
            const SizedBox(height: 10),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Kirana Owner Dashboard',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: const Color(0xFF3B5998), // Calm blue
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          children: [
            buildDashboardItem(
              icon: Icons.inventory_2,
              title: 'Inventory',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const InventoryScreen()),
                );
              },
              color: const Color(0xFF4CAF50), // Green
            ),
            buildDashboardItem(
              icon: Icons.shopping_cart,
              title: 'Orders',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const OrdersScreen()),
                );
              },
              color: const Color(0xFF2196F3), // Blue
            ),
            buildDashboardItem(
              icon: Icons.account_balance_wallet,
              title: 'Udhaar',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const UdhaarScreen()),
                );
              },
              color: const Color(0xFFFF9800), // Orange
            ),
            buildDashboardItem(
              icon: Icons.people,
              title: 'Suppliers',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SuppliersScreen()),
                );
              },
              color: const Color(0xFF9C27B0), // Purple
            ),
            buildDashboardItem(
              icon: Icons.group,
              title: 'Community',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const CommunityScreen()),
                );
              },
              color: const Color(0xFF00BCD4), // Teal
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Chatbot coming soon!')),
          );
        },
        backgroundColor: const Color(0xFF3B5998), // Blue
        child: const Icon(Icons.chat),
      ),
    );
  }
}



