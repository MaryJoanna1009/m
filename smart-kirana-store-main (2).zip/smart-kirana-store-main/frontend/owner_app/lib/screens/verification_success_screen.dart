import 'package:flutter/material.dart';
import 'kirana_dashboard_screen.dart';

class VerificationSuccessScreen extends StatefulWidget {
  const VerificationSuccessScreen({super.key});

  @override
  State<VerificationSuccessScreen> createState() => _VerificationSuccessScreenState();
}

class _VerificationSuccessScreenState extends State<VerificationSuccessScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 1), () {
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const KiranaDashboardScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: const Text(
          "Phone Number Verified!\nRedirecting to Dashboard...",
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 20, color: Color.fromRGBO(0, 0, 0, 1)),
        ),
      ),
    );
  }
}

