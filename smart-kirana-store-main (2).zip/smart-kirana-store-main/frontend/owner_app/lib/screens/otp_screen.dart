import 'package:flutter/material.dart';
import '../services/api_services.dart';
import 'verification_success_screen.dart';

class OTPScreen extends StatefulWidget {
  final String phoneNumber;
  const OTPScreen({super.key, required this.phoneNumber});

  @override
  State<OTPScreen> createState() => _OTPScreenState();
}

class _OTPScreenState extends State<OTPScreen> {
  final TextEditingController otpController = TextEditingController();
  final List<TextEditingController> _controllers =
      List.generate(4, (_) => TextEditingController());
  final List<FocusNode> _focusNodes = List.generate(4, (_) => FocusNode());

  bool isLoading = false;
  bool isResending = false;
  int cooldownSeconds = 0;

  void _verifyOTP() async {
    // combine the 4 boxes into otpController.text
    otpController.text =
        _controllers.map((controller) => controller.text).join();

    String otp = otpController.text.trim();

    if (otp.length != 4) {
      _showSnackBar('Enter a valid 4-digit OTP');
      return;
    }

    setState(() => isLoading = true);

    String? result;
    Object? error;

    try {
      result = await ApiService.verifyOtp(widget.phoneNumber, otp);
    } catch (e) {
      error = e;
    }

    if (!mounted) return;

    setState(() => isLoading = false);

    if (error != null) {
      _showSnackBar('Failed to verify OTP: $error');
      return;
    }

    _showSnackBar(result ?? 'OTP Verified');
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const VerificationSuccessScreen()),
    );
  }

  void _resendOTP() async {
    setState(() {
      isResending = true;
      cooldownSeconds = 30; // cooldown of 30 seconds
    });

    String? otp;
    Object? error;

    try {
      otp = await ApiService.sendOtp(widget.phoneNumber);
    } catch (e) {
      error = e;
    }

    if (!mounted) return;

    setState(() => isResending = false);

    if (error != null) {
      _showSnackBar('Failed to resend OTP: $error');
      return;
    }

    _showSnackBar('OTP resent: $otp');

    _startCooldown();
  }

  void _startCooldown() {
    Future.doWhile(() async {
      if (!mounted) return false;
      if (cooldownSeconds <= 0) return false;

      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;

      setState(() => cooldownSeconds--);
      return true;
    });
  }

  void _showSnackBar(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Widget _buildOTPFields() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: List.generate(4, (index) {
        return SizedBox(
          width: 50,
          child: TextField(
            controller: _controllers[index],
            focusNode: _focusNodes[index],
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            maxLength: 1,
            decoration: const InputDecoration(
              counterText: "",
              border: OutlineInputBorder(),
            ),
            onChanged: (value) {
              if (value.isNotEmpty) {
                if (index < 3) {
                  FocusScope.of(context).requestFocus(_focusNodes[index + 1]);
                } else {
                  FocusScope.of(context).unfocus();
                }
              }
            },
          ),
        );
      }),
    );
  }

  @override
  void dispose() {
    otpController.dispose();
    for (final c in _controllers) {
      c.dispose();
    }
    for (final n in _focusNodes) {
      n.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Phone Verification')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Enter OTP sent to ${widget.phoneNumber}'),
            const SizedBox(height: 20),
            _buildOTPFields(),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: isLoading ? null : _verifyOTP,
              child: isLoading
                  ? const CircularProgressIndicator()
                  : const Text('Verify'),
            ),
            const SizedBox(height: 20),
            Center(
              child: TextButton(
                onPressed: (isResending || cooldownSeconds > 0)
                    ? null
                    : _resendOTP,
                child: isResending
                    ? const Text('Resending...')
                    : cooldownSeconds > 0
                        ? Text('Resend in $cooldownSeconds sec')
                        : const Text('Didn\'t get OTP? Resend Code'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}





