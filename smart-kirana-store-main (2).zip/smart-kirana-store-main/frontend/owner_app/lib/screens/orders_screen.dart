import 'package:flutter/material.dart';

class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Orders'),
        backgroundColor: const Color(0xFF2196F3), // Blue
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: 5,
        itemBuilder: (context, index) {
          return Card(
            elevation: 2,
            margin: const EdgeInsets.symmetric(vertical: 8),
            child: ListTile(
              title: Text('Order #${index + 1}'),
              subtitle: const Text('Customer: John Doe\nItems: 3\nTotal: ₹150'),
              trailing: ElevatedButton(
                onPressed: () {},
                child: const Text('View'),
              ),
            ),
          );
        },
      ),
    );
  }
}
