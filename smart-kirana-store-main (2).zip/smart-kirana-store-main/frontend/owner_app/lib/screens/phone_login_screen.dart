import 'package:flutter/material.dart';
import '../services/api_services.dart';
import 'otp_screen.dart';

class PhoneLoginScreen extends StatefulWidget {
  const PhoneLoginScreen({super.key});

  @override
  State<PhoneLoginScreen> createState() => _PhoneLoginScreenState();
}

class _PhoneLoginScreenState extends State<PhoneLoginScreen> {
  final TextEditingController phoneController = TextEditingController();
  bool isLoading = false;

  void _sendOTP() async {
    String phone = phoneController.text.trim();

    if (phone.length != 10) {
      _showSnackBar('Please enter a valid 10-digit number');
      return;
    }

    setState(() => isLoading = true);

    String? otp;
    Object? error;

    try {
      otp = await ApiService.sendOtp(phone);
    } catch (e) {
      error = e;
    }

    if (!mounted) return;

    setState(() => isLoading = false);

    if (error != null) {
      _showSnackBar('Failed to send OTP: $error');
      return;
    }

    _showSnackBar('OTP sent: $otp');
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => OTPScreen(phoneNumber: phone),
      ),
    );
  }

  void _showSnackBar(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFD7E3FE),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              "Welcome To, కొట్టు",
              style: TextStyle(fontSize: 24, color: Colors.black),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: phoneController,
              keyboardType: TextInputType.phone,
              style: const TextStyle(color: Colors.black),
              decoration: InputDecoration(
                hintText: 'Phone Number',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFD7E3FE),
                padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
              ),
              onPressed: isLoading ? null : _sendOTP,
              child: isLoading
                  ? const CircularProgressIndicator()
                  : const Text("Send OTP"),
            ),
            const SizedBox(height: 10),
            const Text(
              "Don't have an account? Create Now",
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
      ),
    );
  }
}



