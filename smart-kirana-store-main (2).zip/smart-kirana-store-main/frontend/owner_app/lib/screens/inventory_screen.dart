import 'package:flutter/material.dart';
import 'barcode_scanner_screen.dart';

class InventoryScreen extends StatefulWidget {
  const InventoryScreen({super.key});

  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController qtyController = TextEditingController();
  final TextEditingController priceController = TextEditingController();

  final List<Map<String, dynamic>> inventory = [];

  void addItem() {
    final String name = nameController.text.trim();
    final int? qty = int.tryParse(qtyController.text.trim());
    final double? price = double.tryParse(priceController.text.trim());

    if (name.isEmpty || qty == null || price == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter valid details')),
      );
      return;
    }

    setState(() {
      inventory.add({
        'name': name,
        'qty': qty,
        'pricePerUnit': price,
        'totalPrice': qty * price,
      });
      nameController.clear();
      qtyController.clear();
      priceController.clear();
    });
  }

  void removeItem(int index) {
    setState(() {
      inventory.removeAt(index);
    });
  }

  Future<void> openScanner() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const BarcodeScannerScreen()),
    );

    if (!mounted) return;

    if (result != null && result is String) {
      final parts = result.split(',');
      if (parts.length == 3) {
        final name = parts[0].trim();
        final qty = int.tryParse(parts[1].trim());
        final price = double.tryParse(parts[2].trim());

        if (name.isNotEmpty && qty != null && price != null) {
          setState(() {
            inventory.add({
              'name': name,
              'qty': qty,
              'pricePerUnit': price,
              'totalPrice': qty * price,
            });
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Invalid QR Code data')),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('QR Code should be in format: name,qty,price')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Inventory'),
        backgroundColor: const Color(0xFF4CAF50), // Green
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ElevatedButton.icon(
              onPressed: openScanner,
              icon: const Icon(Icons.qr_code_scanner),
              label: const Text('Scan Item'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF4CAF50),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Add Item Manually:',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Item Name',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: qtyController,
                    decoration: const InputDecoration(
                      labelText: 'Quantity',
                      border: OutlineInputBorder(),
                    ),
                    keyboardType: TextInputType.number,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: priceController,
                    decoration: const InputDecoration(
                      labelText: 'Price/unit or kg',
                      border: OutlineInputBorder(),
                    ),
                    keyboardType: TextInputType.number,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: addItem,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2196F3), // Blue
              ),
              child: const Text('Add Item'),
            ),
            const SizedBox(height: 20),
            const Text(
              'Current Inventory:',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: inventory.isEmpty
                  ? const Center(child: Text('No items yet.'))
                  : ListView.builder(
                      itemCount: inventory.length,
                      itemBuilder: (context, index) {
                        final item = inventory[index];
                        return Card(
                          elevation: 2,
                          child: ListTile(
                            title: Text(item['name']),
                            subtitle: Text(
                              'Qty: ${item['qty']} × ₹${item['pricePerUnit']} = ₹${item['totalPrice']}',
                            ),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () => removeItem(index),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

