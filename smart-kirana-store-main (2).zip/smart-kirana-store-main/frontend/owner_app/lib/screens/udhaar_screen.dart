import 'package:flutter/material.dart';

class UdhaarScreen extends StatelessWidget {
  const UdhaarScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Udhaar (Credits)'),
        backgroundColor: const Color(0xFFFF9800), // Orange
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: 5,
        itemBuilder: (context, index) {
          return Card(
            elevation: 2,
            margin: const EdgeInsets.symmetric(vertical: 8),
            child: ListTile(
              title: Text('Customer ${index + 1}'),
              subtitle: const Text('Amount Due: ₹500\nLast Payment: ₹200'),
              trailing: ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                child: const Text('Settle'),
              ),
            ),
          );
        },
      ),
    );
  }
}
