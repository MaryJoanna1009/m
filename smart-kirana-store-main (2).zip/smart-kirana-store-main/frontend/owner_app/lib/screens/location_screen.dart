import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'phone_login_screen.dart';

class LocationScreen extends StatefulWidget {
  const LocationScreen({super.key});

  @override
  State<LocationScreen> createState() => _LocationScreenState();
}

class _LocationScreenState extends State<LocationScreen> {
  String _locationMessage = '';
  String _searchQuery = '';

  Future<void> _detectLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      if (!mounted) return;
      setState(() {
        _locationMessage = 'Location services are disabled.';
      });
      return;
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        if (!mounted) return;
        setState(() {
          _locationMessage = 'Location permission denied.';
        });
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      if (!mounted) return;
      setState(() {
        _locationMessage = 'Location permissions are permanently denied.';
      });
      return;
    }

    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);

    List<Placemark> placemarks =
        await placemarkFromCoordinates(position.latitude, position.longitude);

    String place = placemarks.isNotEmpty
        ? "${placemarks.first.locality}, ${placemarks.first.administrativeArea}"
        : "Unknown location";

    if (!mounted) return;
    setState(() {
      _locationMessage = 'You are in: $place';
    });

    // Navigate to Phone Login Screen after detecting location
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const PhoneLoginScreen()),
    );
  }

  final List<Map<String, dynamic>> popularCities = [
    {"name": "Mumbai", "icon": Icons.location_city},
    {"name": "Delhi-NCR", "icon": Icons.location_city},
    {"name": "Bengaluru", "icon": Icons.location_city},
    {"name": "Hyderabad", "icon": Icons.location_city},
    {"name": "Chandigarh", "icon": Icons.location_city},
    {"name": "Ahmedabad", "icon": Icons.location_city},
    {"name": "Chennai", "icon": Icons.location_city},
    {"name": "Pune", "icon": Icons.location_city},
    {"name": "Kolkata", "icon": Icons.location_city},
    {"name": "Kochi", "icon": Icons.location_city},
  ];

  @override
  Widget build(BuildContext context) {
    final filteredCities = popularCities.where((city) {
      if (_searchQuery.isEmpty) return true;
      return city['name']
          .toString()
          .toLowerCase()
          .contains(_searchQuery.toLowerCase());
    }).toList();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Icon(Icons.store, color: Colors.black),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Search Bar
              Container(
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: TextField(
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                  },
                  decoration: const InputDecoration(
                    hintText: 'Search for your city',
                    prefixIcon: Icon(Icons.menu),
                    suffixIcon: Icon(Icons.search),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.all(16),
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Detect Location Button
              GestureDetector(
                onTap: _detectLocation,
                child: Row(
                  children: const [
                    Icon(Icons.location_on,
                        color: Color.fromRGBO(27, 83, 216, 1)),
                    SizedBox(width: 8),
                    Text(
                      "Detect my Location",
                      style: TextStyle(
                        color: Color.fromRGBO(27, 83, 216, 1),
                        fontSize: 16,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),

              // Show Location Result
              if (_locationMessage.isNotEmpty)
                Text(
                  _locationMessage,
                  style: const TextStyle(color: Colors.black),
                ),

              const SizedBox(height: 30),
              const Text(
                'Popular Cities',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 10),

              // Popular Cities Grid Layout
              GridView.count(
                crossAxisCount: 5,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
                childAspectRatio: 0.8,
                children: filteredCities.map((city) {
                  return GestureDetector(
                    onTap: () {
                      showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: const Text('City Selected'),
                          content: Text('You selected: ${city["name"]}'),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: const Text('OK'),
                            ),
                          ],
                        ),
                      );
                    },
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircleAvatar(
                          radius: 20,
                          backgroundColor: Colors.grey.shade300,
                          child: Icon(city['icon'], color: Colors.black),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          city['name'],
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 10),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 10),

              // View All Cities Link
              GestureDetector(
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: const Text('View All Cities'),
                      content: const Text('You clicked View All Cities'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('OK'),
                        ),
                      ],
                    ),
                  );
                },
                child: const Center(
                  child: Text(
                    'View All Cities',
                    style: TextStyle(
                      color: Color.fromRGBO(0, 0, 0, 1),
                      fontWeight: FontWeight.bold,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

