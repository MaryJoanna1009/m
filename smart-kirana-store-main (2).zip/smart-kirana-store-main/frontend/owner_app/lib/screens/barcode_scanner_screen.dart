import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class BarcodeScannerScreen extends StatefulWidget {
  const BarcodeScannerScreen({super.key});

  @override
  State<BarcodeScannerScreen> createState() => _BarcodeScannerScreenState();
}

class _BarcodeScannerScreenState extends State<BarcodeScannerScreen> {
  bool isScanned = false;

  void handleBarcode(BarcodeCapture capture) {
    if (isScanned) return;

    final Barcode? barcode = capture.barcodes.firstOrNull;

    if (barcode != null && barcode.rawValue != null) {
      setState(() {
        isScanned = true;
      });

      Navigator.pop(context, barcode.rawValue);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Scanned: ${barcode.rawValue}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan Item'),
        backgroundColor: const Color(0xFF4CAF50), // Green
      ),
      body: Stack(
        children: [
          MobileScanner(
            onDetect: handleBarcode,
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              padding: const EdgeInsets.all(12),
              color: Colors.black54,
              child: const Text(
                'Align the barcode within the frame to scan',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

