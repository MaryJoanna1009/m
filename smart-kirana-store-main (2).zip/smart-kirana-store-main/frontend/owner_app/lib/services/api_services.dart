import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static String baseUrl = "http://192.168.1.11:8000"; // adjust if needed

  /// Send OTP
  static Future<String> sendOtp(String phoneNumber) async {
    final url = Uri.parse("$baseUrl/auth/send_otp?phone_number=$phoneNumber");

    final response = await http.post(url);

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['otp']; // Note: show only for dev
    } else {
      throw Exception('Failed to send OTP: ${response.body}');
    }
  }

  /// Verify OTP
  static Future<String> verifyOtp(String phoneNumber, String otp) async {
    final url = Uri.parse(
        "$baseUrl/auth/verify_otp?phone_number=$phoneNumber&otp=$otp");

    final response = await http.post(url);

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['message'];
    } else {
      throw Exception('OTP verification failed: ${response.body}');
    }
  }
}


