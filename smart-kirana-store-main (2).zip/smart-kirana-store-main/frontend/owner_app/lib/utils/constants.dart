class Constants {
  static const String baseUrl = 'http://192.168.1.54:5000';
  static const String jwtTokenKey = 'jwt_token';
}