from fastapi import APIRouter, HTTPException
import random

router = APIRouter(prefix="/auth", tags=["Auth"])

# In-memory OTP storage
otp_store = {}

@router.post("/send_otp")
def send_otp(phone_number: str):
    """
    Send OTP to the given phone number.
    Example: POST /auth/send_otp?phone_number=9876543210
    """
    otp = str(random.randint(1000, 9999))
    otp_store[phone_number] = otp

    return {"message": "OTP sent", "otp": otp}

@router.post("/verify_otp")
def verify_otp(phone_number: str, otp: str):
    """
    Verify OTP for the given phone number.
    Example: POST /auth/verify_otp?phone_number=9876543210&otp=1234
    """
    if otp_store.get(phone_number) == otp:
        return {"message": "OTP Verified. Login successful"}
    raise HTTPException(status_code=400, detail="Invalid OTP")





