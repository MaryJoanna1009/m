from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List

router = APIRouter(prefix="/owner", tags=["Owner"])

# Dummy Product DB
product_db = []

class Product(BaseModel):
    id: int
    name: str
    price: float
    quantity: int

@router.get("/products", response_model=List[Product])
def get_products():
    return product_db

@router.post("/products")
def add_product(product: Product):
    product_db.append(product)
    return {"message": "Product added"}

@router.put("/products/{product_id}")
def update_product(product_id: int, updated_product: Product):
    for index, prod in enumerate(product_db):
        if prod.id == product_id:
            product_db[index] = updated_product
            return {"message": "Product updated"}
    raise HTTPException(status_code=404, detail="Product not found")

@router.delete("/products/{product_id}")
def delete_product(product_id: int):
    for prod in product_db:
        if prod.id == product_id:
            product_db.remove(prod)
            return {"message": "Product deleted"}
    raise HTTPException(status_code=404, detail="Product not found")


