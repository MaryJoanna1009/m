from fastapi import APIRouter

router = APIRouter(prefix="/admin", tags=["Admin"])

@router.get("/status")
def get_status():
    return {"status": "Admin module working"}


