from fastapi import APIRouter

router = APIRouter(prefix="/role", tags=["Role"])

@router.get("/roles")
def list_roles():
    return {"roles": ["owner", "customer", "admin"]}

