from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List

router = APIRouter(prefix="/customer", tags=["Customer"])

# Dummy Order DB
order_db = []

class Order(BaseModel):
    id: int
    customer_name: str
    product_name: str
    quantity: int

@router.get("/orders", response_model=List[Order])
def get_orders():
    return order_db

@router.post("/order")
def place_order(order: Order):
    order_db.append(order)
    return {"message": "Order placed"}


