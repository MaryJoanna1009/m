from fastapi import APIRouter

router = APIRouter(prefix="/settings", tags=["Settings"])

@router.get("/config")
def get_settings():
    return {"settings": "Default Store Settings"}

