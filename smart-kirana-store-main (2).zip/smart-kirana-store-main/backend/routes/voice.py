from fastapi import APIRouter

router = APIRouter(prefix="/voice", tags=["Voice"])

@router.get("/test")
def test_voice():
    return {"message": "Voice module placeholder"}

