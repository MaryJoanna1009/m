from fastapi import FastAPI
from backend.routes import auth, owner, customer, admin, role, settings, voice

app = FastAPI()

app.include_router(auth.router)
app.include_router(owner.router)
app.include_router(customer.router)
app.include_router(admin.router)
app.include_router(role.router)
app.include_router(settings.router)
app.include_router(voice.router)

@app.get("/")
def root():
    return {"message": "Smart Kirana Store Backend Running"}


