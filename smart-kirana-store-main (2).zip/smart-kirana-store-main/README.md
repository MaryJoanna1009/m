# Smart Kirana Store OS

An AI-powered OS for local kirana stores in India.  
Built using Flutter (Frontend), Flask (Backend), and Machine Learning (AI Module).

## 📦 Project Structure
- `/frontend`: Flutter mobile app
- `/backend`: Flask backend APIs
- `/ai`: AI/ML logic and scripts
- `/docs`: Diagrams, reports, planning

## ✅ Features
- Inventory tracking
- Udhaar (credit) management
- AI-based color + product recommendation
- Voice-enabled order entry
- Sales insights for shopkeepers
- Community for kirana store owners 

## 👥 Team Roles
- Surya Neha Sureddi– Backend setup, AI module, API integration + deployment
- Mary Joanna – UI/UX design, Flutter app development, API integration
- Mohmmed Altaf Baig – Research, documentation, competitor study, testing, and demo prep