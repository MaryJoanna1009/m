/
├── /login
├── /register
├── /select-role             # [Kirana Owner | Customer] → only visible on first login
│
├── /dashboard               # Main route → dynamic redirect to appropriate dashboard:
│   ├── /owner               # Only if role === 'owner'
│   │   ├── /inventory
│   │   │   ├── /add
│   │   │   ├── /low-stock
│   │   │   └── /expired
│   │   ├── /udhaar
│   │   │   ├── /add
│   │   │   └── /history
│   │   ├── /orders
│   │   │   ├── /incoming
│   │   │   ├── /packing-list
│   │   │   └── /status
│   │   ├── /loyalty
│   │   ├── /suppliers
│   │   │   ├── /compare
│   │   │   └── /reorder
│   │   ├── /chatbot
│   │   └── /community
│
│   ├── /customer            # Only if role === 'customer'
│   │   ├── /store           # View local store info
│   │   ├── /browse
│   │   ├── /cart
│   │   ├── /order
│   │   │   └── /status
│   │   ├── /rewards
│   │   ├── /history
│   │   └── /support
│
│   └── /admin               # Only if role === 'admin' (fully hidden)
│       ├── /stores
│       ├── /analytics
│       ├── /suppliers
│       ├── /chatbot-train
│       ├── /push-messages
│       └── /reports
│
├── /voice                   # Shared voice interface
├── /settings                # Profile settings (name, phone, etc.)
└── /logout
